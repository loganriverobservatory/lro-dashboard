const { chromium } = require('C:\\Users\\A02443985\\AppData\\Local\\npm-cache\\_npx\\e41f203b7505f1fb\\node_modules\\playwright');
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  await page.setViewportSize({ width: 1400, height: 900 });
  await page.goto('http://localhost:5175');
  await page.click('text=LIST VIEW');
  await page.waitForTimeout(10000);
  await page.screenshot({ path: 'screenshot_now.png' });
  const cards = await page.locator('.station-card').count();
  console.log('Cards:', cards);
  errors.forEach(e => console.log('[error]', e));
  await browser.close();
})().catch(e => { console.error(e.message); process.exit(1); });
