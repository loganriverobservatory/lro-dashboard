<script setup lang="ts">
/*
SchematicView.vue - Renders one schematic page (Upper Logan Canyon / Lower Logan River /
Blacksmith Fork River, selected by the `slug` route param) as a Vue Flow node/edge diagram,
driven entirely by the page's public/schematics/{slug}.json config. The config only says what
each node IS (kind + connectsTo + side) - this file derives where it goes and how it connects;
Vue Flow just owns node positioning, edge routing, and pan/zoom/touch once handed that.
*/
import { ref, computed, onMounted, onBeforeUnmount, watch, nextTick, markRaw, provide } from 'vue'
import { useRouter } from 'vue-router'
import {
  VueFlow,
  MarkerType,
  useVueFlow,
  type Node as VFNode,
  type Edge as VFEdge,
} from '@vue-flow/core'
import { Plus, Minus, RotateCcw } from 'lucide-vue-next'
import '@vue-flow/core/dist/style.css'
import {
  type Station,
  type SchematicSlug,
  type SchematicPageConfig,
  type SchematicNode as SchematicNodeData,
  WATER_VARIBALES,
  bestFuzzyMatch,
} from '../hydroService'
import SchematicNode from '../components/SchematicNode.vue'
import StationCard from '../components/StationCard.vue'

const props = defineProps<{
  slug: SchematicSlug
  sites: Station[]
  loading: boolean
  activeWaterways?: string[]
  // Manifest-ordered {slug, label} list from App.vue - drives the mobile tab bar below so
  // it reflects whichever schematic JSON files an adopter has configured, in manifest order.
  schematicNav: { slug: SchematicSlug; label: string }[]
  selectedVariable?: string
}>()

const router = useRouter()
const { fitView, zoomIn, zoomOut, onNodesInitialized } = useVueFlow()

const nodeTypes = { schematic: markRaw(SchematicNode) }

// Fuller form used in "Live {{ variableLongLabel }}" (e.g. "Discharge in cfs (cubic feet per
// second)") - same source and pattern as ListView.vue's own status-banner, so the two read
// identically. Falls back to the short label if this variable isn't in WATER_VARIBALES.
const variableLongLabel = computed(() => {
  const match = WATER_VARIBALES.find((v) => v.id === props.selectedVariable)
  return match?.longLabel ?? props.selectedVariable ?? ''
})

const page = ref<SchematicPageConfig | null>(null)
const pageLoadFailed = ref(false)
const selectedStation = ref<Station | null>(null)
const isCompact = ref(false)
const wideChains = ref(false)

// Must stay comfortably wider than the fixed node width set in SchematicNode.vue, so
// adjacent columns never overlap.
const COL_WIDTH = 560
const ROW_HEIGHT = 170

// Keep in sync with SchematicNode.vue's .schematic-node / .kind-junction widths.
const NODE_WIDTH = 380
const JUNCTION_WIDTH = 10

// The main channel's lane. A direct trunk attachment is always +/-1 from this. A multi-stop
// chain extends further out from there (see computeLayout's wideChains handling) rather than
// adding more fixed lanes.
const CENTER_COL = 2

// Above this viewport width, a multi-stop canal/chain branches out sideways (one column per
// stop) instead of stacking vertically - see computeLayout(). Below it (including all mobile
// widths), chains always stack vertically since there's no room to spread out.
const WIDE_CHAINS_BREAKPOINT = 1200

async function loadPage() {
  page.value = null
  pageLoadFailed.value = false
  try {
    const res = await fetch(`/schematics/${props.slug}.json`, { cache: 'no-cache' })
    page.value = res.ok ? ((await res.json()) as SchematicPageConfig) : null
  } catch {
    page.value = null
  }
  pageLoadFailed.value = page.value === null
}

function findLiveStation(node: SchematicNodeData): Station | undefined {
  const match = node.stationId
    ? props.sites.find((site) => site.code === node.stationId)
    : bestFuzzyMatch(node.name, props.sites, (site) => site.displayName)
  if (!match) return undefined
  if (props.activeWaterways && !props.activeWaterways.includes(match.tributary ?? ''))
    return undefined
  return match
}

// Generic river-system labels - when one of these sits before the colon in a live display
// name, it's pure boilerplate (the diagram already conveys which system you're on via the
// page and trunk position), so it gets dropped. Matches the same river names used elsewhere
// for group colors (WATERWAY_COLORS / SCHEMATIC_ACCENT_COLORS).
const RIVER_SYSTEM_LABELS = ['Logan River', 'Blacksmith Fork River', 'Little Bear River']

// Schematic-only display shortening. Two unrelated patterns show up in live display names,
// and they need opposite treatment:
//  - "Logan River: Franklin Basin" - generic river prefix, specific place after the colon.
//    Drop the prefix, keep the place: "Franklin Basin".
//  - "Right Hand Fork: Before Confluence with Logan River" - here the SPECIFIC name (the
//    tributary itself) is the prefix, and "Before Confluence with ..." is the boilerplate.
//    Keep the prefix, drop the rest entirely: "Right Hand Fork".
// Telling them apart: is the prefix one of the generic river-system labels, or a specific
// tributary/creek/fork name? Only in the former case is there a fallback needed at all - a
// couple of mainstem stations have nothing BUT "Before Confluence with X" after a generic
// prefix (e.g. "Logan River: Before Confluence with Cutler Reservoir"), so that case falls
// back to showing the confluence target itself.
// Only ever applied to display text - matching against live stations always uses the raw
// name, before this runs.
function shortenForSchematic(name: string): string {
  const colonIndex = name.indexOf(':')
  if (colonIndex === -1) return name.trim()

  const prefix = name.slice(0, colonIndex).trim()
  const rest = name.slice(colonIndex + 1).trim()

  if (!RIVER_SYSTEM_LABELS.includes(prefix)) {
    // Specific tributary/creek/fork name - that IS the useful identifier, so keep it and
    // drop the redundant "Before Confluence with the main channel" that follows.
    return prefix
  }

  const confluenceMatch = rest.match(/Before Confluence with\s+(?:the\s+)?(.+)$/i)
  return confluenceMatch ? confluenceMatch[1]!.trim() : rest
}

// The trunk is everything that sits inline on the main channel: real gauge stations
// (mainstem), invisible confluence dots (junction), and a 'link' node with no connectsTo -
// a page-boundary card that's just the next stop on the channel, not a side attachment
// (e.g. upper-logan's "Continue to Lower Logan River" card).
function isTrunk(node: SchematicNodeData): boolean {
  return (
    node.kind === 'mainstem' ||
    node.kind === 'junction' ||
    (node.kind === 'link' && !node.connectsTo)
  )
}

// Everything else attaches to the trunk, or chains onto another attachment, via connectsTo.
function isBranch(node: SchematicNodeData): boolean {
  return (
    node.kind === 'tributary' ||
    node.kind === 'diversion' ||
    (node.kind === 'link' && !!node.connectsTo)
  )
}

interface Layout {
  col: number
  row: number
}

// Places one trunk node's own attached branches (its "forest": every branch node whose
// connectsTo chain leads back to this trunk node before reaching any other trunk node),
// starting at rootRow. A direct trunk attachment always stacks vertically below any sibling
// sharing the same attachment point and side, in both layouts. A CHAIN CONTINUATION (attaching
// to another branch card, not the trunk itself) also stacks vertically when wideChains is
// false - but when wideChains is true, it instead extends sideways from its immediate anchor,
// staying on the same row, so a multi-stop canal reads as a left-to-right row of cards instead
// of a tall stack (only on screens wide enough to have room for that - see
// WIDE_CHAINS_BREAKPOINT). Used twice by computeLayout(): once to measure how many rows a
// trunk node's forest needs (so trunk spacing can reserve enough room), and once for real,
// once that spacing is known.
function placeForest(
  nodesById: Map<string, SchematicNodeData>,
  rootId: string,
  rootRow: number,
  forest: SchematicNodeData[],
  layoutOut: Map<string, Layout>,
  wideChains: boolean,
) {
  const occupied = new Set<string>()
  const nextFreeRowByGroup = new Map<string, number>()

  // Multiple passes: a chain link can't be placed until whatever it connectsTo (the root, or
  // another branch node in this same forest) already has a position. Each pass places
  // anything whose anchor is now known; repeats until nothing new gets placed. This handles a
  // simple one-hop branch and a multi-hop chain (a canal with several stops along it) the same
  // way, without needing to walk chains explicitly.
  let pending = forest.slice()
  let progressed = true
  while (pending.length && progressed) {
    progressed = false
    const stillPending: SchematicNodeData[] = []
    for (const node of pending) {
      const anchor = node.connectsTo ? nodesById.get(node.connectsTo) : undefined
      if (!anchor) {
        stillPending.push(node)
        continue
      }
      const isRootAttachment = anchor.id === rootId
      const anchorPos = isRootAttachment
        ? { col: CENTER_COL, row: rootRow }
        : layoutOut.get(anchor.id)
      if (!anchorPos) {
        stillPending.push(node)
        continue
      }

      const side = node.side ?? 'left'
      const outward = side === 'left' ? -1 : 1
      let col: number
      let row: number

      if (wideChains && !isRootAttachment) {
        col = anchorPos.col + outward
        row = anchorPos.row
        while (occupied.has(`${col}:${row}`)) col += outward
      } else {
        col = CENTER_COL + outward
        const groupKey = `${anchor.id}:${side}`
        row = nextFreeRowByGroup.get(groupKey) ?? anchorPos.row
        while (occupied.has(`${col}:${row}`)) row++
        nextFreeRowByGroup.set(groupKey, row + 1)
      }

      layoutOut.set(node.id, { col, row })
      occupied.add(`${col}:${row}`)
      progressed = true
    }
    pending = stillPending
  }

  // Anything left has a missing or cyclic connectsTo (malformed data) - place it rather than
  // silently dropping it from the diagram, so a bad edit is visible instead of invisible.
  pending.forEach((node) => {
    const side = node.side ?? 'left'
    const col = side === 'left' ? CENTER_COL - 1 : CENTER_COL + 1
    let row = rootRow
    while (occupied.has(`${col}:${row}`)) row++
    layoutOut.set(node.id, { col, row })
    occupied.add(`${col}:${row}`)
  })
}

// Derives every node's (col, row) from kind + connectsTo + side + file order alone - this
// replaces hand-typed row/col numbers. Trunk row spacing is NOT fixed at 1 - each trunk node's
// gap to the next one is sized to fit whatever its own attached branches need (measured with a
// first "dry run" placement, below), so a long canal chain grows the diagram taller (or, in
// wideChains mode, wider - see placeForest) instead of spilling into the next junction's own
// branches. side/column is never adjusted to dodge a collision - it stays exactly what the
// JSON says (side is meant to reflect which bank of the river a station is really on), the
// diagram just expands to fit it.
function computeLayout(page: SchematicPageConfig, wideChains: boolean): Map<string, Layout> {
  const nodesById = new Map(page.nodes.map((n) => [n.id, n]))
  const trunkNodes = page.nodes.filter(isTrunk)
  const branchNodes = page.nodes.filter(isBranch)

  // Which trunk node "owns" a branch node - walks connectsTo up until it reaches a trunk node,
  // so a multi-hop chain is attributed to the trunk node at its root, not an intermediate link.
  function ownerTrunkOf(node: SchematicNodeData): string | undefined {
    let current: SchematicNodeData | undefined = node
    const seen = new Set<string>()
    while (current && !seen.has(current.id)) {
      seen.add(current.id)
      if (isTrunk(current)) return current.id
      current = current.connectsTo ? nodesById.get(current.connectsTo) : undefined
    }
    return undefined
  }

  const forestByTrunk = new Map<string, SchematicNodeData[]>()
  for (const node of branchNodes) {
    const owner = ownerTrunkOf(node)
    if (!owner) continue
    if (!forestByTrunk.has(owner)) forestByTrunk.set(owner, [])
    forestByTrunk.get(owner)!.push(node)
  }

  // Pass 1: assign trunk rows, growing the gap after each trunk node to fit whatever its own
  // forest needs (measured via a throwaway placement, starting that forest at a local row
  // equal to the trunk node's own row).
  let row = 1
  const layout = new Map<string, Layout>()
  trunkNodes.forEach((t) => {
    layout.set(t.id, { col: CENTER_COL, row })

    const forest = forestByTrunk.get(t.id) ?? []
    const probeLayout = new Map<string, Layout>()
    placeForest(nodesById, t.id, row, forest, probeLayout, wideChains)
    let maxRow = row
    probeLayout.forEach((pos) => {
      if (pos.row > maxRow) maxRow = pos.row
    })

    row = Math.max(row + 1, maxRow + 1)
  })

  // Pass 2: place every branch for real, now that trunk spacing has already reserved enough
  // room for it.
  trunkNodes.forEach((t) => {
    const forest = forestByTrunk.get(t.id) ?? []
    placeForest(nodesById, t.id, layout.get(t.id)!.row, forest, layout, wideChains)
  })

  // Anything whose connectsTo never resolved back to a trunk node (malformed/cyclic data) -
  // place it rather than silently dropping it from the diagram.
  branchNodes.forEach((node) => {
    if (layout.has(node.id)) return
    const side = node.side ?? 'left'
    const col = side === 'left' ? CENTER_COL - 1 : CENTER_COL + 1
    const occupied = new Set(Array.from(layout.values()).map((p) => `${p.col}:${p.row}`))
    let r = 1
    while (occupied.has(`${col}:${r}`)) r++
    layout.set(node.id, { col, row: r })
  })

  return layout
}

const layoutByPage = computed(() =>
  page.value ? computeLayout(page.value, wideChains.value) : new Map<string, Layout>(),
)

const vfNodes = computed<VFNode[]>(() => {
  if (!page.value) return []
  const layout = layoutByPage.value
  return page.value.nodes.map((node: SchematicNodeData): VFNode => {
    const pos = layout.get(node.id) ?? { col: CENTER_COL, row: 1 }
    const xOffset = node.kind === 'junction' ? (NODE_WIDTH - JUNCTION_WIDTH) / 2 : 0
    const isStationKind =
      node.kind === 'mainstem' || node.kind === 'tributary' || node.kind === 'diversion'
    const liveStation = isStationKind ? findLiveStation(node) : undefined
    return {
      id: node.id,
      type: 'schematic',
      position: { x: pos.col * COL_WIDTH + xOffset, y: pos.row * ROW_HEIGHT },
      data: {
        kind: node.kind,
        name: shortenForSchematic(node.name),
        label: node.label,
        description: node.description,
        colorGroup: node.colorGroup,
        terminus: node.terminus,
        linkTo: node.linkTo,
        liveStation: liveStation
          ? {
              ...liveStation,
              displayName: node.cardLabel ?? shortenForSchematic(liveStation.displayName),
            }
          : undefined,
      },
    }
  })
})

const STYLE_PRESETS = {
  main: { stroke: '#1e293b', strokeWidth: 4 },
  in: { stroke: '#475569', strokeWidth: 3 }, // tributary, or a link flowing toward its anchor
  out: { stroke: '#c2703d', strokeWidth: 3 }, // diversion flowing away from its anchor
} as const

const vfEdges = computed<VFEdge[]>(() => {
  if (!page.value) return []
  const layout = layoutByPage.value
  const nodesById = new Map(page.value.nodes.map((n) => [n.id, n]))
  const colOf = (id: string) => layout.get(id)?.col ?? CENTER_COL
  // Pick vertical (top/bottom) handles when both ends share a column — this is what keeps
  // the main channel a single straight line — or horizontal (left/right) handles when a
  // lateral tributary/diversion sits in a different column, so it branches cleanly out to
  // the side instead of routing through a boxy up/down S-curve.
  function makeEdge(
    id: string,
    source: SchematicNodeData,
    target: SchematicNodeData,
    preset: (typeof STYLE_PRESETS)[keyof typeof STYLE_PRESETS],
  ): VFEdge {
    const sourceCol = colOf(source.id)
    const targetCol = colOf(target.id)
    let sourceHandle = 's-bottom'
    let targetHandle = 't-top'
    let edgeShape: 'straight' | 'smoothstep' = 'straight'
    if (sourceCol < targetCol) {
      sourceHandle = 's-right'
      targetHandle = 't-left'
      edgeShape = 'smoothstep'
    } else if (sourceCol > targetCol) {
      sourceHandle = 's-left'
      targetHandle = 't-right'
      edgeShape = 'smoothstep'
    }

    return {
      id,
      source: source.id,
      target: target.id,
      sourceHandle,
      targetHandle,
      type: edgeShape,
      style: { stroke: preset.stroke, strokeWidth: preset.strokeWidth },
      // Main-channel edges only get an arrowhead where they actually land on a station
      // card (mainstem) - into a junction's barely-visible dot, an arrowhead has nothing
      // to visually land on and just reads as noise. Lateral tributary/diversion
      // connectors always keep theirs, since each is its own short hop where direction is
      // the whole point.
      markerEnd:
        preset === STYLE_PRESETS.main && target.kind !== 'mainstem'
          ? undefined
          : { type: MarkerType.ArrowClosed, color: preset.stroke, width: 16, height: 16 },
    }
  }

  const edges: VFEdge[] = []

  const trunk = page.value.nodes.filter(isTrunk)
  for (let i = 0; i < trunk.length - 1; i++) {
    edges.push(
      makeEdge(
        `trunk-${trunk[i]!.id}-${trunk[i + 1]!.id}`,
        trunk[i]!,
        trunk[i + 1]!,
        STYLE_PRESETS.main,
      ),
    )
  }

  page.value.nodes.forEach((node) => {
    if (!isBranch(node) || !node.connectsTo) return
    const target = nodesById.get(node.connectsTo)
    if (!target) return

    // 'diversion' flows away from its anchor, so the arrowhead needs to land on the
    // diversion, not the anchor — swap source/target rather than juggling markerStart vs
    // markerEnd, so every edge can just use markerEnd.
    const reversed = node.kind === 'diversion'
    const preset = reversed ? STYLE_PRESETS.out : STYLE_PRESETS.in
    edges.push(
      makeEdge(`branch-${node.id}`, reversed ? target : node, reversed ? node : target, preset),
    )

    if (node.returnsTo) {
      const returnTarget = nodesById.get(node.returnsTo)
      if (returnTarget)
        edges.push(makeEdge(`return-${node.id}`, node, returnTarget, STYLE_PRESETS.in))
    }
  })

  return edges
})

// SchematicNode.vue can't receive props directly (Vue Flow controls what it passes to a
// custom node type), so a "view full system" button on any node reaches navigation via
// inject('navigateToSystem') instead. 'link'-kind nodes (a whole-card navigation link, no
// button) go through onNodeClick below instead, same as the rest of node-click handling.
provide('navigateToSystem', (slug: SchematicSlug) => router.push(`/schematic/${slug}`))

function onNodeClick({ node }: { node: VFNode }) {
  const data = node.data as VFNode['data'] & {
    kind: SchematicNodeData['kind']
    linkTo?: SchematicSlug
    liveStation?: Station
  }
  if (data.kind === 'link' && data.linkTo) {
    router.push(`/schematic/${data.linkTo}`)
    return
  }
  if (isCompact.value && data.liveStation) {
    // data.liveStation's displayName has been shortened for the on-canvas card - the detail
    // popup should show the real, full name, so look the station back up by id rather than
    // reuse that shortened copy.
    selectedStation.value =
      props.sites.find((site) => site.id === data.liveStation!.id) ?? data.liveStation
  }
}

function closeStation() {
  selectedStation.value = null
}

// The mobile system-select dropdown navigates on change, same destination as clicking a tab.
function onSystemSelect(event: Event) {
  const target = event.target as HTMLSelectElement
  router.push(`/schematic/${target.value}`)
}

function updateBreakpoints() {
  isCompact.value = window.innerWidth <= 768
  wideChains.value = window.innerWidth >= WIDE_CHAINS_BREAKPOINT
}

// Re-fits the view to every node on the current page - shared by initial load, switching
// systems, the "Reset" control button, and window resize, so the diagram never keeps a stale
// pan/zoom from a different viewport size or a previously-viewed system.
function resetView() {
  fitView({ padding: 0.05 })
}

let resizeTimer: ReturnType<typeof setTimeout> | null = null

// Debounced resize handler - re-checks breakpoints and re-fits the view shortly after
// resizing stops, instead of on every tick.
function handleResize() {
  if (resizeTimer) clearTimeout(resizeTimer)
  resizeTimer = setTimeout(async () => {
    updateBreakpoints()
    await nextTick()
    resetView()
  }, 150)
}

onNodesInitialized(() => {
  resetView()
})

onMounted(() => {
  updateBreakpoints()
  window.addEventListener('resize', handleResize)
  loadPage()
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  if (resizeTimer) clearTimeout(resizeTimer)
})

watch(
  () => props.slug,
  async () => {
    selectedStation.value = null
    await loadPage()
    // Wait for vfNodes/vfEdges (and Vue Flow's own internal node measurement) to catch up to
    // the new page before fitting - onNodesInitialized alone doesn't reliably re-fire on every
    // slug switch since the node *elements* persist across pages, only their data changes.
    await nextTick()
    resetView()
  },
)
</script>

<template>
  <div class="schematic-container">
    <div class="header-row">
      <div class="header-block">
        <div class="title-row">
          <select
            class="system-select-title"
            :value="slug"
            aria-label="Switch schematic system"
            @change="onSystemSelect"
          >
            <option v-for="system in schematicNav" :key="system.slug" :value="system.slug">
              {{ system.label }}
            </option>
          </select>
          <span v-if="page?.subtitle" class="subtitle-inline">{{ page.subtitle }}</span>
        </div>

        <div v-if="variableLongLabel" class="status-banner">
          <h2>Live {{ variableLongLabel }}</h2>
        </div>
      </div>
    </div>

    <div v-if="loading || !page" class="loading-state">
      <template v-if="pageLoadFailed">
        <p>Couldn't load this schematic page. Try refreshing.</p>
      </template>
      <template v-else>
        <div class="spinner"></div>
        <p>Loading schematic…</p>
      </template>
    </div>

    <div v-else class="vueflow-wrapper">
      <VueFlow
        :nodes="vfNodes"
        :edges="vfEdges"
        :node-types="nodeTypes"
        :nodes-draggable="false"
        :nodes-connectable="false"
        :elements-selectable="false"
        :pan-on-drag="true"
        :zoom-on-pinch="true"
        :zoom-on-double-click="false"
        :prevent-scrolling="true"
        :min-zoom="0.15"
        :max-zoom="1.5"
        :fit-view-on-init="true"
        @node-click="onNodeClick"
      >
        <!-- Custom zoom controls rather than Vue Flow's stock Controls component, so all
        three buttons can share one uniform icon-button style (see .zoom-icon-btn below)
        instead of Vue Flow's default styling and a mismatched text-label Reset button. -->
        <div class="zoom-control-group">
          <p class="zoom-controls-label">Zoom Controls</p>
          <div class="zoom-btn-row">
            <button type="button" class="zoom-icon-btn" aria-label="Zoom out" @click="zoomOut()">
              <Minus :size="isCompact ? 11 : 14" />
            </button>
            <button type="button" class="zoom-icon-btn" aria-label="Zoom in" @click="zoomIn()">
              <Plus :size="isCompact ? 11 : 14" />
            </button>
            <button
              type="button"
              class="zoom-icon-btn"
              aria-label="Reset view"
              title="Reset view"
              @click="resetView"
            >
              <RotateCcw :size="isCompact ? 11 : 14" />
            </button>
          </div>
          <p v-if="!loading && page" class="corner-hint">Scroll/pinch to Zoom</p>
        </div>
      </VueFlow>
    </div>

    <div v-if="selectedStation" class="station-sheet-backdrop" @click="closeStation">
      <div class="station-sheet" @click.stop>
        <button class="sheet-close" type="button" aria-label="Close" @click="closeStation">
          &times;
        </button>
        <StationCard :site="selectedStation!" />
      </div>
    </div>
  </div>
</template>

<style scoped>
.schematic-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  font-size: 1rem;
  font-weight: 600;
  color: #073763;
  letter-spacing: -0.01em;
  padding: 0.85rem 1.25rem;
  box-sizing: border-box;
}

@media screen and (max-width: 640px) {
  .schematic-container {
    padding: 0.6rem 0.6rem;
  }
}

.header-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 0.6rem;
  /* Stays pinned to the top of the page while scrolling, rather than scrolling out of view -
     the system switcher should stay reachable without scrolling back up. */
  position: sticky;
  top: 0;
  z-index: 20;
  background: #f8fafc;
  padding: 6px 0;
}

.header-block {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 4px;
}

.title-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
}

/* Page-level "Discharge shown in cfs" indicator, replacing what used to be repeated on every
   single station card (see SchematicNode.vue - the per-card unit text is hidden there now).
   Sits directly under the title row, styled identically to ListView.vue's own "Live Discharge
   in cfs..." box (same class names/values) so both views show the exact same banner. */
.status-banner {
  background-color: #e0f2fe;
  padding: 10px;
  border-radius: 8px;
}

.status-banner h2 {
  font-size: 0.95rem;
  font-weight: 700;
  margin: 0;
}

@media screen and (max-width: 480px) {
  .status-banner h2 {
    font-size: 0.8rem;
  }
}

/* The page "title" at every screen size - a functional system-switcher dropdown styled to
   read as a heading, rather than a big static title on desktop and a separate small dropdown
   on mobile. */
.system-select-title {
  appearance: none;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  background: #ffffff;
  color: #073763;
  font-family: inherit;
  font-size: 1.05rem;
  font-weight: 600;
  letter-spacing: -0.01em;
  padding: 6px 30px 6px 12px;
  cursor: pointer;
  max-width: 100%;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23073763' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  background-size: 16px;
}

@media screen and (max-width: 480px) {
  .system-select-title {
    font-size: 0.9rem;
  }
}

.subtitle-inline {
  color: #475569;
  font-family:
    system-ui,
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    sans-serif;
  font-size: 0.9rem;
  font-weight: 400;
}

.loading-state {
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem;
  gap: 15px;
  color: #64748b;
}

.spinner {
  width: 32px;
  height: 32px;
  border: 3px solid #e2e8f0;
  border-top: 3px solid #01377d;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/* Positions the pan/zoom hint and the custom zoom-button row together in the bottom-left
   corner, where Vue Flow's own default Controls component used to sit before it was replaced
   with fully custom buttons (see .zoom-icon-btn below). */
.zoom-control-group {
  position: absolute;
  bottom: 10px;
  left: 10px;
  z-index: 5;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 6px;
}

.zoom-controls-label {
  margin: 0;
  padding: 0 1px;
  color: #64748b;
  font-family:
    system-ui,
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    sans-serif;
  font-size: 0.68rem;
  font-weight: 700;
  white-space: nowrap;
  text-shadow:
    0 1px 2px rgba(255, 255, 255, 0.9),
    0 0 6px rgba(255, 255, 255, 0.9);
}

.corner-hint {
  display: flex;
  align-items: center;
  gap: 5px;
  margin: 0;
  padding: 0 1px;
  color: #64748b;
  font-family:
    system-ui,
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    sans-serif;
  font-size: 0.68rem;
  font-weight: 600;
  white-space: nowrap;
  text-shadow:
    0 1px 2px rgba(255, 255, 255, 0.9),
    0 0 6px rgba(255, 255, 255, 0.9);
}

/* Zoom out/in/Reset - three identical icon buttons, side by side at every screen size.
   Styled to match Leaflet's default zoom control used in MapView.vue (white square,
   thin border, black icon, subtle shadow) rather than the app's usual navy pill buttons. */
.zoom-btn-row {
  display: flex;
  align-items: center;
  gap: 6px;
}

.zoom-icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 4px;
  border: 1px solid rgba(0, 0, 0, 0.25);
  background: #ffffff;
  color: #000000;
  cursor: pointer;
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.4);
  transition: background 0.18s ease;
}

.zoom-icon-btn:hover {
  background: #f4f4f4;
}

/* Same threshold as isCompact (768px) elsewhere in this file - on mobile all three buttons
   shrink slightly further, staying side by side rather than stacking. */
@media screen and (max-width: 768px) {
  .zoom-icon-btn {
    width: 26px;
    height: 26px;
  }
}

.vueflow-wrapper {
  position: relative;
  width: 100%;
  flex: 1;
  min-height: 320px;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  background: #f8fafc;
  touch-action: none;
  overflow: hidden;
}

.station-sheet-backdrop {
  position: fixed;
  inset: 0;
  z-index: 1000;
  background: rgba(15, 23, 42, 0.45);
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.station-sheet {
  position: relative;
  width: 100%;
  max-width: 560px;
  max-height: 85vh;
  overflow-y: auto;
  background: #ffffff;
  border-radius: 16px 16px 0 0;
  padding: 1.25rem 1rem 1.5rem;
  box-shadow: 0 -8px 30px rgba(0, 0, 0, 0.2);
  animation: sheet-up 0.22s ease;
}

@keyframes sheet-up {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}

.sheet-close {
  position: absolute;
  top: 8px;
  right: 12px;
  z-index: 1;
  border: none;
  background: transparent;
  font-size: 1.8rem;
  line-height: 1;
  color: #64748b;
  cursor: pointer;
  padding: 4px 10px;
}

.sheet-close:hover {
  color: #1e293b;
}

.station-sheet :deep(.card-flex-layout) {
  flex-direction: column;
  align-items: stretch;
  gap: 0.75rem;
}
.station-sheet :deep(.sparkline-sidebar-wrapper) {
  width: 100%;
}
.station-sheet :deep(.sparkline-title) {
  text-align: left;
}
.station-sheet :deep(.sparkline-sidebar-wrapper .cursor-pointer) {
  height: auto !important;
  aspect-ratio: 9 / 4;
}
</style>
