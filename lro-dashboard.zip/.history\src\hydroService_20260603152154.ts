// src/hydroService.ts
import type { DatastreamExtended } from '@hydroserver/client'

const BASE_URL = 'https://lro.hydroserver.org/api/sensorthings/v1.1'

interface StaLocation {
  location: { geometry: { coordinates: [number, number, ...number[]] } }
}

interface StaThing {
  '@iot.id': string
  Locations?: StaLocation[]
}

interface StaDatastream {
  '@iot.id': string | number
  name: string
  description?: string
  unitOfMeasurement?: { symbol: string }
  Thing?: StaThing
  properties?: Pick<DatastreamExtended, 'isVisible' | 'status' | 'sampledMedium' | 'isPrivate'>
}

export interface StaObservation {
  '@iot.id': string | number
  result: number | null
  phenomenonTime: string | null
}

// Each View pulls from Station interface
export interface Station {
  id: string
  uuid: string
  displayName: string
  description?: string
  observation?: StaObservation | null
  coordinates: [number, number] | null
  unit?: string
}

export const WATER_VARIBALES = [
  { id: 'Discharge', label: 'Discharge (cfs)' },
  { id: 'Water Temperature', label: 'Temperature (°C)' },
  { id: 'Specific Conductance', label: 'SPC (uS/cm)' },
  { id: 'pH', label: 'pH' },
  { id: 'Oxygen, dissolved', label: 'Dissolved Oxygen' },
]

// Add or remove station codes here to control which sites appear in all views
const STATIONS_NOT_DISPLAYED = [
  'TF_SAWM_A', // decommissioned
  'SPC_CONF_A', // decommissioned
  'SLB_600W_CNL', // canal
  'NWF_1600N_CNL', // canal
  'LR_RH_SD', // storm drain
  'LR_SC_SD', // storm drain
  'LR_DSC_A', // decommissioned
]

function getCoordinates(ds: any): [number, number] | null {
  const p = ds.Thing?.Locations?.[0]?.location?.geometry?.coordinates

  if (p && p.length >= 2) {
    // API is [Lon, Lat], Map needs [Lat, Lon]
    return [p[1], p[0]]
  } else {
    return null
  }
}

const STATION_NAME_MAP: Record<string, string> = {
  BC_CONF_A: 'Beaver Creek: Before Confluence with the Logan River',
  BSF_1700S_A: 'Blacksmith Fork River: 1700 South Footbridge',
  BSF_CONF_BA: 'Blacksmith Fork River: Before Confluence with Logan River',
  BSF_Darwin_A: 'Blacksmith Fork River: Hollow Road',
  DS_CONF_A: 'Dewitt Springs: Before Confluence with Logan River',
  LBR_MR_A: 'Little Bear River: Mendon Road',
  LR_1000W_A: 'Logan River: 1000 West',
  LR_Cutler_A: 'Logan River: Before Confluence with Cutler Reservoir',
  LR_FB_BA: 'Logan River: Franklin Basin',
  LR_GCB_A: 'Logan River: Guinavah Campground',
  LR_MainStreet_BA: 'Logan River: Main Street',
  LR_Mendon_AA: 'Logan River: Mendon Road',
  LR_TG_BA: 'Logan River: Tony Grove',
  LR_WaterLab_AA: 'Logan River: Utah Water Research Laboratory',
  LR_WC_A: 'Logan River: Above Wood Camp',
  LR_WCB_A: 'Logan River: Wood Camp Bridge',
  RHF_CONF_A: 'Right Hand Fork: Before Confluence with Logan River',
  RS_CONF_A: 'Ricks Spring: Before Confluence with Logan River',
  SC_CONF_A: 'Spring Creek: Before Confluence with Logan River',
  SC_MR_A: 'Spring Creek: Mendon Road',
  TF_CONF_A: 'Temple Fork: Before Confluence with Logan River',
  LR_DSC_A: 'Logan River: Dewitt Springs Campground',
}

export async function getVariableStations(variable: string = 'Discharge'): Promise<Station[]> {
  const isDischarge = variable.toLowerCase() === 'discharge'

  const varFilter = isDischarge
    ? `contains(name,'Discharge') and contains(name,'cfs') and not contains(name,'cms')`
    : `contains(name,'${variable}')`

  const listUrl = `${BASE_URL}/Datastreams?$filter=${varFilter}&$top=50&$orderby=name asc&$expand=Thing($expand=Locations)`

  const response = await fetch(listUrl)
  const data = await response.json()

  return data.value
    .filter((ds: StaDatastream) => {
      const code = ds.name.split(' ')[0]
      if (STATIONS_NOT_DISPLAYED.includes(code)) return false
      const isDecommissioned =
        ds.description?.includes('Decommissioned') || ds.name?.includes('Decommissioned')
      const isTesting = ds.name?.includes('Testing')
      return !isDecommissioned && !isTesting
    })
    .map((ds: StaDatastream) => {
      const stationCode = ds.name.split(' ')[0]
      const foundCoords = getCoordinates(ds)

      return {
        id: ds['@iot.id']?.toString(),
        uuid: ds.Thing?.['@iot.id']?.toString() || '',
        displayName: STATION_NAME_MAP[stationCode] || stationCode,
        description: ds.description,
        observation: { '@iot.id': '', result: null, phenomenonTime: null },
        coordinates: foundCoords,
        unit: ds.unitOfMeasurement?.symbol || '',
      }
    })
}

export async function getLatestObservation(stationId: string): Promise<StaObservation | null> {
  const obsUrl = `${BASE_URL}/Datastreams('${stationId}')/Observations?$top=1&$orderby=phenomenonTime desc`
  const response = await fetch(obsUrl)
  const data = await response.json()
  return data.value?.[0] || null
}

export function isStationActive(observation: StaObservation | null): boolean {
  return true
}

export type FreshnessStatus = 'current' | 'stale' | 'outdated' | 'unknown'

export function getFreshnessStatus(observation: StaObservation | null): FreshnessStatus {
  if (!observation?.phenomenonTime) return 'unknown'
  const ageHours = (Date.now() - new Date(observation.phenomenonTime).getTime()) / (1000 * 60 * 60)
  if (ageHours < 2) return 'current'
  if (ageHours < 24) return 'stale'
  return 'outdated'
}
